<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\venta;

class VentasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        venta::factory(5000)->create();
    }
}
