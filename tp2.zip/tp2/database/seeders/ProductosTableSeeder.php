<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\producto;

class ProductosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        producto::factory(5000)->create();
    }
}
